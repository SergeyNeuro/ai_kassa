

imit_data = [
    {
        "dish_data": [
            {
                "id": 1,
                "name": "Дрон",
                "menu_id": 1,
                "code_name": "Drone",
                "type": 1,
                "count_type": 11,
                "count": 1,
                "price": 1000,
                "changing_dish_id": None
            },
            {
                "id": 1,
                "name": "Муха",
                "menu_id": 1,
                "code_name": "fly",
                "type": 1,
                "count_type": 11,
                "count": 1,
                "price": 300,
                "changing_dish_id": None
            },
            {
                "id": 1,
                "name": "Вертолет",
                "menu_id": 1,
                "code_name": "helicopter",
                "type": 1,
                "count_type": 11,
                "count": 1,
                "price": 6000,
                "changing_dish_id": None
            },
        ],
       "x1": 351,
       "y1": 54,
       "x2": 534,
       "y2": 162
    },
    {
        "dish_data": {
            "id": 1,
            "name": "Человек",
            "menu_id": 1,
            "code_name": "human",
            "type": 1,
            "count_type": 11,
            "count": 1,
            "price": 3000,
            "changing_dish_id": None
        },
       "x1": 83,
       "y1": 218,
       "x2": 300,
       "y2": 630
    },
    {
        "dish_data": [
            {
                "id": 1,
                "name": "Телефон",
                "menu_id": 1,
                "code_name": "Phone",
                "type": 1,
                "count_type": 11,
                "count": 1,
                "price": 500,
                "changing_dish_id": None
            },
            {
                "id": 1,
                "name": "Пульт",
                "menu_id": 1,
                "code_name": "pult",
                "type": 1,
                "count_type": 11,
                "count": 1,
                "price": 6000,
                "changing_dish_id": None
            },
       ],
       "x1": 142,
       "y1": 441,
       "x2": 235,
       "y2": 515
    },
]